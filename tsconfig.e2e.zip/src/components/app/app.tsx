import { AppHeader, IngredientDetails, Modal, OrderInfo } from '@components';
import {
  ConstructorPage,
  Feed,
  ForgotPassword,
  Login,
  NotFound404,
  Profile,
  ProfileOrders,
  Register,
  ResetPassword,
} from '@pages';
import { Route, Routes, useLocation, useNavigate } from 'react-router-dom';

import type { Location } from 'react-router-dom';

import '../../index.css';

import styles from './app.module.css';

type LocationState = {
  background?: Location;
};

const App = (): React.JSX.Element => {
  const location = useLocation();
  const backgroundLocation = (location.state as LocationState | null)?.background;

  const navigate = useNavigate();

  const handleCloseModal = (): void => {
    void navigate(-1);
  };

  return (
    <div className={styles.app}>
      <AppHeader />
<Routes>
  <Route
    path="/ingredients/:id"
    element={<h1>Маршрут ингредиента работает</h1>}
  />
  <Route
    path="*"
    element={<h1>Сработал маршрут 404 из App</h1>}
  />
</Routes>

      {backgroundLocation && (
        <Routes>
          <Route
            path="/ingredients/:id"
            element={
              <Modal title="Детали ингредиента" onClose={handleCloseModal}>
                <IngredientDetails />
              </Modal>
            }
          />
          <Route
            path="/feed/:number"
            element={
              <Modal title="Информация о заказе" onClose={handleCloseModal}>
                <OrderInfo />
              </Modal>
            }
          />
          <Route
            path="/profile/orders/:number"
            element={
              <Modal title="Информация о заказе" onClose={handleCloseModal}>
                <OrderInfo />
              </Modal>
            }
          />
        </Routes>
      )}
    </div>
  );
};

export default App;
